<? 
    error_reporting(0);
    ob_start();
    session_start();

 require_once('lib/wp-db.php');
 require_once('lib/functions.php');

 require_once('header.php');
 //require_once('sidebar-left.php');
 
 
?>
<div id="maincolumn-page" style="text-align: center;">
  <div class="nopad" style="display:inline-block; text-align: center; ">
    <div class="title-page-item" style="font-size: 22px;margin-top: 18px;margin: auto;
    width: 50%; text-align: center;">CÔNG TY CỔ PHẦN THẾ GIỚI SỐ</div>
     <img src="images/dw-logo.png" alt=""/>
        <div class="news-content">
          <p class="MsoNormal" style="text-align: justify;"></p>
          <p style="margin: 0in 0in 0.0001pt 0.25in; text-indent: -0.25in;" class="MsoNormal"></p>
          <p style="margin: 0in 0in 0.0001pt 0.25in; text-indent: -0.25in; text-align: justify;" class="MsoNormal"></p>
          <p style="margin: 0in 0in 0.0001pt 0.25in; text-indent: -0.25in; line-height: 170%;" class="MsoNormal">
            <strong> <span style="line-height: 170%; font-size: 10pt; font-family: tahoma,sans-serif;"></span> </strong></p>
          <p class="MsoNormal" style="margin: 6pt 0in 6pt 0.25in; text-indent: -0.25in; line-height: 150%;">
              <span style="font-family: tahoma; font-size: 13px;">
              <span style="line-height: 150%;">Tên Công ty:<strong>&nbsp;CÔNG TY CỔ PHẦN THẾ GIỚI SỐ </strong></span>
              <span style="line-height: 150%;"><o:p></o:p>
              </span>
              </span>
              </p>
          <p style="margin: 6pt 0in 6pt 0.25in; text-indent: -0.25in; line-height: 150%;">
            <span style="line-height: 150%; font-family: tahoma; font-size: 13px;">Tên giao dịch tiếng Anh:<strong> DIGITAL WORLD JSC.</strong>
             </span>
             </p>
          <p style="margin: 6pt 0in 6pt 0.25in; text-indent: -0.25in; line-height: 150%;">
            <span style="line-height: 150%; font-family: tahoma; font-size: 13px;">Địa chỉ:<strong> 31- Phan Đình Giót, Quận Thanh Xuân, Thành phố Hà Nội</strong>
           </span></p>
          <p style="margin: 6pt 0in; line-height: 150%;">
             <span style="line-height: 150%; font-family: tahoma; font-size: 13px;">Giấy CNĐKKD và Mã số doanh nghiệp số:<strong>&nbsp;0101217009 (số cũ: 0103018927) đăng ký thay đổi lần thứ 28&nbsp;do Sở Kế hoạch &amp; Đầu tư Thành phố Hà Nội cấp ngày 29/5/2015</strong>
              </span></p>
          <p style="margin: 6pt 0in; line-height: 150%;">
             <span style="line-height: 150%; font-family: tahoma; font-size: 13px;">Đại diện theo pháp luật của doanh nghiệp:<strong> Bà.... - Chủ tịch HĐQT kiêm Tổng Giám đốc</strong> </span></p>
          <p style="margin: 6pt 0in; line-height: 150%;">
          <span style="font-family: tahoma;"><strong>
          <span style="line-height: 150%; font-size: 18px;">1- Giới thiệu chung</span></strong>
           </span></p>
          <p style="margin: 6pt 0in; line-height: 150%; text-align: justify;">
            <span style="font-family: tahoma; font-size: 13px;">
            <span style="line-height: 150%;">Công ty cổ phần Thế Giới Số được thành lập theo Quyết định số 0102004703 ngày 11/3/2002 của Sở Kế hoạch và Đầu tư Thành phố Hà Nội. Công ty đã chính thức chuyển đổi từ mô hình công ty trách nhiệm hữu hạn sang mô hình công ty cổ phần với tên gọi mới là&nbsp;</span>
            <a href="http://www.trananh.vn/">
              <span style="line-height: 150%; color: blue;">Công ty cổ phần Thế Giới Số</span></a>
              <span style="line-height: 150%;">&nbsp;kể từ ngày 08/8/2007 theo Giấy CNĐKKD số 0103018927 do Sở Kế hoạch và Đầu tư Thành phố Hà Nội cấp và đã chuyển sang số mới là 0101217009 kể từ ngày 29/5/2015.</span>
              </span>
        </p>
         <p style="margin: 6pt 0in; line-height: 150%; text-align: justify;">
           <span style="font-family: tahoma; font-size: 13px;">
           <span style="line-height: 150%;">Ngày đầu thành lập, Công ty cổ phần Thế Giới Số chỉ có 5 người làm việc trong một cửa hàng nhỏ với diện tích hơn 60m<sup>2</sup>. Sau hơn 14 năm hoạt động, hiện nay quy mô Công ty đã tăng lên con số gần 3.000 nhân viên và </span>
           <span style="line-height: 150%; color: blue;"><a href="http://www.trananh.vn/he-thong-sieu-thi-dien-may-tran-anh">2<span style="color: blue;">8</span> </a>trung tâm bán lẻ</span>
           <span style="line-height: 150%;"> (trong đó có 5 trung tâm bán lẻ khai trương vào Quý III/2016). </span></span></p>

<p style="margin: 6pt 0in; line-height: 150%; text-align: justify;"><span style="line-height: 150%; font-family: tahoma; font-size: 13px;">Năm 2017, với mục tiêu lựa chọn chất lượng dịch vụ khách hàng làm mũi nhọn cạnh tranh, Công ty sẽ không tập trung mở rộng quy mô như năm 2016 mà sẽ chỉ mở thêm khoảng 10 -12 siêu thị, vừa phủ kín các tỉnh thành lớn ở miền Bắc và miền Trung.</span></p>
<p style="margin: 6pt 0in; line-height: 150%; text-align: justify;"><span style="line-height: 150%; font-family: tahoma; font-size: 13px;">
Thay vào đó, Công ty sẽ tập trung vào 5 mục tiêu lớn:</span></p>
<p style="margin: 6pt 0in; line-height: 150%; text-align: justify;"><span style="line-height: 150%; font-family: tahoma; font-size: 13px;">
<strong>Thứ nhất</strong>: Chất lượng dịch vụ khách hàng  phải nằm trong Top đầu trên thị trường điện máy.<br>
<strong>Thứ hai:</strong> Thu nhập của nhân viên nằm trong Top đầu doanh nghiệp có thu nhập nhân viên cao trên thị trường.<br>
<strong>Thứ 3:</strong> Trình độ tư vấn, phục vụ, giao tiếp khách hàng của nhân viên  có sự&nbsp; nổi trội so với thị trường<br>
<strong>Thứ 4:</strong> Doanh thu trên từng điểm bán của được cải thiện tối đa so với năng lực của từng điểm bán<br>
<strong>Thứ 5:</strong> Hệ thống phần mềm quản trị của công ty sẽ được đầu tư mạnh mẽ giúp cho việc phân tích, quản trị và ra quyết định chính xác, hiệu quả.<br>
</span></p>
<p style="margin: 6pt 0in; line-height: 150%; text-align: justify;"><span style="font-family: tahoma; font-size: 13px;"><span style="line-height: 150%;">Gắn liền với quá trình hoạt động và phát triển của Trần Anh là chính sách kinh doanh, dịch vụ hậu mãi tuyệt vời như: Chính sách Thẻ khách hàng thân thiết, Chính sách 1 đổi 1 trong vòng 30 ngày đối với sản phẩm lỗi, Chính sách Bao giá trong vòng 15 ngày, </span><a href="http://www.trananh.vn/tin-tuc/tin-khuyen-mai-c919"><span style="line-height: 150%; color: blue;">chính sách kinh doanh</span></a><span style="line-height: 150%;"> "<em>đưa sản phẩm chính hãng, giá tốt nhất đến tận tay người tiêu dùng</em>", phục vụ theo phương châm “<em>Khách hàng là Thượng đế</em>”, </span><a href="http://www.trananh.vn/tin-tuc/chinh-sach/chinh-sach-bao-hanh-tran-anh-n516"><span style="line-height: 150%; color: blue;">chính sách bảo hành</span></a><span style="line-height: 150%;"> "<em>1 đổi 1</em>”, bán hàng trả góp lãi suất ưu đãi và </span><a href="http://www.trananh.vn/tin-tuc/chinh-sach/chinh-sach-van-chuyen-mien-phi-toan-mien-bac-n1272"><span style="line-height: 150%; color: blue;">dịch vụ giao hàng</span></a><span style="line-height: 150%;"> “<em>vận chuyển, lắp đặt miễn phí trong vòng bán kính 100km</em>”</span></span></p>

<p style="margin: 6pt 0in; line-height: 150%; text-align: justify;"><span style="line-height: 150%; font-family: tahoma; font-size: 13px;">Đặc biệt,  luôn cập nhật các sản phẩm công nghệ mới và luôn có các chương trình <span style="text-decoration: underline; color: blue;"><a href="http://www.trananh.vn/khuyenmai.htm">khuyến mãi</a></span> đặc sắc: giá cả ưu đãi, quà tặng phong phú tới Khách hàng.</span></p>

<p style="margin: 6pt 0in; line-height: 150%; text-align: justify;"><span style="font-family: tahoma; font-size: 13px;"><strong><span style="line-height: 150%; color: red;">Khách hàng mới là người quyết định tương lai, sự tồn tại và phát triển của công ty</span></strong><strong> </strong></span></p>
<p style="margin: 6pt 0in; line-height: 150%; text-align: justify;"><span style="line-height: 150%; font-family: tahoma; font-size: 13px;">Vì vậy, toàn thể cán bộ, nhân viên Công ty  đều luôn tâm niệm và làm việc theo suy nghĩ:</span></p>
<p style="margin: 6pt 0in; line-height: 150%; text-align: justify;"><span style="font-family: tahoma; font-size: 13px;"><strong><span style="line-height: 150%; color: red;">Hãy phục vụ Khách hàng như chúng ta đang phục vụ chính bản thân chúng ta!</span></strong><strong> </strong></span></p>
<p style="margin: 6pt 0in; line-height: 150%; text-align: justify;"><span style="font-family: tahoma;"><strong><span style="line-height: 150%; font-size: 18px;">2- Tầm nhìn của Công ty</span></strong></span></p>

<p style="margin: 6pt 0in; line-height: 150%; text-align: justify;"><span style="font-family: tahoma;"><strong><span style="line-height: 150%; font-size: 18px;">3- Giá trị cốt lõi của Công ty</span></strong></span></p>
<p style="margin: 6pt 0in; line-height: 150%; text-align: justify;"><span style="line-height: 150%; font-family: tahoma; font-size: 13px;">- <strong>Kỷ luật</strong> hướng vào tính chuyên nghiệp;</span></p>
<p style="margin: 6pt 0in; line-height: 150%; text-align: justify;"><span style="line-height: 150%; font-family: tahoma; font-size: 13px;">- <strong>Hoàn thiện</strong> tổ chức hướng tới dịch vụ hàng đầu;</span></p>
<p style="margin: 6pt 0in; line-height: 150%; text-align: justify;"><span style="line-height: 150%; font-family: tahoma; font-size: 13px;">- <strong>Năng động</strong> hướng tới tính sáng tạo tập thể;</span></p>
<p style="margin: 6pt 0in; line-height: 150%; text-align: justify;"><span style="line-height: 150%; font-family: tahoma; font-size: 13px;">- <strong>Cam kết</strong>&nbsp;với nội bộ và cộng đồng, xã hội;</span></p>
<p style="margin: 6pt 0in; line-height: 150%; text-align: justify;"><span style="line-height: 150%; font-family: tahoma; font-size: 13px;">- Làm việc và hành động <strong>trung thực</strong>;</span></p>
<p style="margin: 6pt 0in; line-height: 150%; text-align: justify;"><span style="line-height: 150%; font-family: tahoma; font-size: 13px;">-&nbsp;Hoạt động <strong>hiệu quả</strong> hướng tới<strong> </strong>hiệu quả doanh nghiệp và xã hội.</span></p>
<p style="margin: 6pt 0in; line-height: 150%; text-align: center;"><span style="line-height: 150%; font-family: tahoma; font-size: 13px;"><img alt="" src="images/CAU_THANG-02.png" style="width: 679px; height: 352px; vertical-align: top; margin: 0px; border-width: 0px; border-style: solid;"> <br>
</span></p>

<br>
<p></p>
<p style="line-height: 170%;" class="MsoNormal"><o:p></o:p></p>
<p></p>
<p></p>
<p></p>
                        
<!-- <img class="icon_price" src="https://lib.trananh.com.vn/images/15_tags.png" width="18" alt="Tags"> -->
  
                    </div>
                </div>
  </div>



<? require_once('sidebar-right.php')?>
<?require_once('footer.php')?>