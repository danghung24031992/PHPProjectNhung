        <div class="clr"></div>
        <div id="footer">
            <div class="left-logo">
          <a href="index.php"><img src="images/dw-logo.png" /> </a>
        </div>
        </div><!--end #footer-->
        
        
    </div><!--end #container-->

</body>
</html>