<?php

//echo strtotime(date('Y-m-d'));

date_modify('20-1-2017','Y-m-d');

?>